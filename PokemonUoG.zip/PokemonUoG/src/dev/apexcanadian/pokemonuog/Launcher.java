package dev.apexcanadian.pokemonuog;

public class Launcher {
	
	public static void main(String[] args) {
		Game game = new Game("Pokemon UoG", 767, 639);
		game.start();
	}
}
